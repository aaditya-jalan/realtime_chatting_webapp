import { Box, Typography, styled } from "@mui/material";
import { useContext } from "react";
import { AccountContext } from '../constants/contexts/AccountProvider'; 
import React from "react";
import { Fragment } from "react";

// For Box 1 we need the profile picture that we have stored in context, so we import the context
// We have account details in the AccountContext

// Styling for profile picture
const Dp = styled("img")({
    width: 200,
    height: 200,
    borderRadius: "50%",
    padding: '25px 0px'
});

// For Material-UI defined components we can use template literals
const DescriptionBox = styled(Box)`
    padding: 15px 20px 28px 30px;
    & > p {
        font-size: 13px;
        color: #b0bec5; // Light gray for description text in dark mode
    }
`;

const ImageBox = styled(Box)`
    display: flex;
    justify-content: center;
`;

const NameBox = styled(Box)`
    background: #424242; // Dark background for name box
    padding: 12px 30px 2px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
    & :first-child {
        font-size: 13px;
        font-weight: 200;
        color: #80cbc4; // Teal color for first child text
    }
    & :last-child {
        margin: 14px 0;
        color: #eeeeee; // Light gray for last child text
    }
`;

function Profile() {
    const { account } = useContext(AccountContext);
    
    return (
        <Fragment>
            <ImageBox>
                <Dp src={account.picture} alt="dp" />
            </ImageBox>
            <NameBox>
                <Typography>Your name</Typography>
                <Typography>{account.name}</Typography>
            </NameBox>
            {/* Third box just contains the paragraph element */}
            <DescriptionBox>
                <Typography>
                    This is not your username or PIN. This name will be visible to your WhatsApp contacts.
                </Typography>
            </DescriptionBox>
            <NameBox>
                <Typography>About</Typography>
                <Typography>hakunamatata</Typography>
            </NameBox>
        </Fragment>
    );
}

export default Profile;
