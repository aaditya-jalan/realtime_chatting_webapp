import { Box, styled } from '@mui/material';

const Component = styled(Box)`
  background: #000; // Pitch black background
  padding: 30px 0;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Container = styled(Box)`
  padding: 0 20px; // Adjusted padding for better alignment
`;

const EmptyChat = () => {
  return (
    <Component>
      <Container>
        {/* Content removed as requested */}
      </Container>
    </Component>
  );
}

export default EmptyChat;
