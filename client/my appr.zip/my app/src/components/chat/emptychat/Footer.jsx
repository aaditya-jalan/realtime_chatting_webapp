import { Box,InputBase,styled } from "@mui/material";
import { SmileyIcon } from "./icons";
import { MicIcon,PlusIcon } from "./icons";
import { useState } from "react";
import { useEffect } from "react";
//import { uploadFile } from "../../../service/api";
const Container= styled(Box)`
height:60 px;
display:flex;
background:#ededed;
width:845px;
align-items:center;
justify-content:space-between;
padding:0 15px;
& > *{
    margin:5px;
    color: #919191;
}
`;
const Search=styled(Box)`
background-color:#FFFFFF;
border-radius:18px;
width:700px;
`;
const InputField= styled(InputBase)`
    width:100%;
    padding:20px;
    height:20px;
    font-size:14px;
    
`;

const  Footer=({sendText,setValue,value,file,setFile})=>{
    // useEffect(()=>{
    //     const getImage= async()=>{
    //         if(file){
    //             const data=new FormData(); // we cannot send file directly we need to send the data in chunks 
    //             data.append("name",file.name);
    //             data.append("file",file);
    //             //now our data is formed 
    //             //the file is sent in form of binary data
    //             //so we call the api
    //             await uploadFile(data);
    //         }
    //     }
    //     getImage();
    // },[file])
    const onFileChange=(e)=>{
        console.log(e);
        setFile(e.target.files[0]);
        setValue(e.target.files[0].name)
    }
    return<Container>
        <SmileyIcon/>
        <label htmlFor="fileInput">
        <PlusIcon/>
        </label>
        
        <input type="file"
            id="fileInput"
            style={{display:'none'}}
            onChange={(e)=>onFileChange(e)}
        />

        <Search>
            <InputField
                placeholder="Type a message"
                onChange={(e)=>setValue(e.target.value)}
                onKeyPress={(e)=>sendText(e)}
                value={value}
            />
        </Search>
        <MicIcon/>
        
    </Container>
    
}
export default Footer;