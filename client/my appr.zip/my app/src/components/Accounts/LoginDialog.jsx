import { jwtDecode } from "jwt-decode";
import { useContext } from "react";
import { Dialog, Typography, Box, styled } from '@mui/material';
import { GoogleLogin } from '@react-oauth/google';
import { AccountContext } from "../constants/contexts/AccountProvider";
import { addUser } from "../../service/api";

const dialogStyle = {
  height: "96%",
  marginTop: "12%",
  width: "60%",
  maxWidth: "100%",
  maxHeight: "100%",
  boxShadow: "none",
  overflow: "hidden",
  backgroundColor: "#000", // Pitch black background
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
};

const Title = styled(Typography)`
  font-size: 28px;
  font-weight: 300;
  color: #ffffff; // White text color for contrast
  font-family: inherit;
  text-align: center;
  margin-bottom: 40px; // Add some space below the title
`;

const LoginButtonWrapper = styled(Box)`
  display: flex;
  justify-content: center;
`;

function LoginDialog() {
  const { setPage } = useContext(AccountContext);
  const { setAccount } = useContext(AccountContext);

  function onLoginError(res) {
    console.log(res);
  }

  async function onLoginSuccess(res) {
    let decoded = jwtDecode(res.credential);
    setAccount(decoded);
    setPage(1);
    console.log(decoded);
    await addUser(decoded);
    console.log("User added");
  }

  return (
    <Dialog open={true} PaperProps={{ sx: dialogStyle }} hideBackdrop={true}>
      <Box>
        <Title>Welcome to the Chatting App. Please login to continue.</Title>
        <LoginButtonWrapper>
          <GoogleLogin
            onSuccess={onLoginSuccess}
            onError={onLoginError}
            shape="pill"
            theme="filled_black"
            size="large"
          />
        </LoginButtonWrapper>
      </Box>
    </Dialog>
  );
}

export default LoginDialog;
