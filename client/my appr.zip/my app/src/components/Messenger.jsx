import React, { Fragment } from "react";
import LoginDialog from "./Accounts/LoginDialog";
import { AppBar, Box, Toolbar, styled } from '@mui/material';
import ChatDialog from "./chat/chatdialog";
import { useContext } from "react";
import { AccountContext } from "./constants/contexts/AccountProvider"; // imported the context

const LoginHeader = styled(AppBar)({
    height: "220px",
    boxShadow: "none",
    backgroundColor: "#121212", // Dark background
});

const ChatHeader = styled(AppBar)({
    height: "125px",
    boxShadow: "none",
    backgroundColor: "#ffffff", // Slightly lighter dark background
});

const Component = styled(Box)({
    height: "100vh",
    backgroundColor: "#ffffff", // Dark grey background
    color: "#ffffff", // White text for contrast
});

function Messenger() {
    const { account } = useContext(AccountContext); // using account variable
    const { page } = useContext(AccountContext);
    const { setPage } = useContext(AccountContext);

    function btnCli() {
        setPage(0);
    }

    return (
        <Component>
            {account ? (
                page === 5 ? (
                    <Fragment>
                        <h1>Hello</h1>
                        <button onClick={btnCli}>Click Me</button>
                    </Fragment>
                ) : (
                    <Fragment>
                        <ChatHeader>
                            <Toolbar>
                                <ChatDialog />
                            </Toolbar>
                        </ChatHeader>
                    </Fragment>
                )
            ) : (
                <Fragment>
                    <LoginHeader>
                        <Toolbar>
                            <LoginDialog />
                        </Toolbar>
                    </LoginHeader>
                </Fragment>
            )}
        </Component>
    );
}

export default Messenger;
